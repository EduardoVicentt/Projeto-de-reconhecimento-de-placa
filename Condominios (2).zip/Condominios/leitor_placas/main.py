from typing import Any

def ler_placa():
    import cv2
    import imutils
    import pytesseract
    import numpy as np

    #Para se usar o Tesseract no Python, temos que indicar onde o mesmo esta instalado juntamente com seu executavel
    pytesseract.pytesseract.tesseract_cmd = "C:\Program Files\Tesseract-OCR\tesseract.exe"

    img = cv2.imread('img_1.png')


    kernel = np.ones((3, 3), np.uint8)

    img=imutils.resize(img, width=520)

    cinza = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imshow("cinza", cinza)

    _,bin = cv2.threshold(cinza, 70, 255, cv2.THRESH_BINARY)

    cv2.imshow("bin", bin)

    desfoque = cv2.GaussianBlur(bin, (5, 5), 0)
    cv2.imshow("desfoque", desfoque)

    dilatacao = cv2.erode(bin, kernel, iterations=1)
    cv2.imshow("dilatacao", dilatacao)

    erosao = cv2.dilate(dilatacao, kernel, iterations=1)
    cv2.imshow("erosao", erosao)

    cv2.waitKey(0)

    con = r'-c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 --psm 6'
    text = pytesseract.image_to_string(erosao,lang='eng', config=con)
    print("Number is : ",text)  
    # Inserir código do Eduardo Jorge aqui
    # Deve retornar um texto contendo o valor da placa
pass

def main():
    nome_arquivo = "./src/static/placa.txt"

    placa = ler_placa()

    with open(nome_arquivo, "w") as arquivo:
        arquivo.write(placa)

    print("Arquivo criado com sucesso!")

if __name__ == "__main__":
    main()
