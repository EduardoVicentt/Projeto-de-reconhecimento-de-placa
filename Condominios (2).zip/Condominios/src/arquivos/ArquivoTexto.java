package arquivos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;


public class ArquivoTexto {
    public String ler_arquivo_placa() {
        String nomeArquivo = ".\\src\\static\\placa.TXT";
        try {
            FileReader fileReader = new FileReader(nomeArquivo);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String linha, placa = null;
            
            while ((linha = bufferedReader.readLine()) != null) {
                System.out.println("Placa lida!");
                if (linha != null){
                    placa = linha;
                }
            }
            
            bufferedReader.close();
            return placa;
        } catch (IOException e) {
            System.out.println("Ocorreu um erro ao ler a placa: " + e.getMessage());
            return null;
        }
    }
    
    public void excluir_arquivo() {
        String nomeArquivo = ".\\src\\static\\placa.TXT";
        
        File arquivo = new File(nomeArquivo);
        
        if (arquivo.delete()) {
            System.out.println("Arquivo apagado com sucesso!");
        } else {
            System.out.println("Falha ao apagar o arquivo.");
        }
    }
}
