
package ProprietarioData;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ProprietarioDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;
    

    public ProprietarioDao() {
    }
    
    public boolean conectar(){
        try {
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            //conn = DriverManager.getConnection("jdbc:sqlserver://localhost;database=banco;integratedSecurity=true;");  
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/condominio", "root","");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
           return false;           
        } 
    }
    
     public int salvar(Proprietarioo proprietario){
        int status;
        try {
            
            
            
            st = conn.prepareStatement("INSERT INTO ptoprietarios VALUES(?,?,?,?)");
            st.setString(1, proprietario.getNome());
            st.setString(2, proprietario.getData_nasc());
            st.setString(3, proprietario.getCpf());
            st.setString(4, proprietario.getRg());
            st.setString(5, proprietario.getTelefone());
            st.setString(6, proprietario.getCelular());
             st.setString(7, proprietario.getEmail());
           
            status = st.executeUpdate();
            return status; //retorna 1
        } catch (SQLException ex) {
            return ex.getErrorCode(); 
            //1062 tentativa de inserir uma matrícula já cadastrada.
        }
    }

    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }

    public Proprietarioo consultar (String cpf){
        try {
            Proprietarioo proprietario = new Proprietarioo();
            st = conn.prepareStatement("SELECT * FROM proprietarios WHERE cpf=?");
            st.setString(1,cpf);
            rs = st.executeQuery();
            // verifica se a consulta encontrou o carro com a placa informada
            if(rs.next()){ // se encontrou o carro
                
                
                proprietario.setCpf(rs.getString("cpf"));
                proprietario.setNome(rs.getString("nome"));
                proprietario.setEmail(rs.getString("email"));
                proprietario.setTelefone(rs.getString("telefone"));
                proprietario.setCelular(rs.getString("celular"));
                proprietario.setRg(rs.getString("rg"));
                proprietario.setData_nasc(rs.getString("data_cad"));
                
                return proprietario;
                
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null;
        }
       
    }

   public boolean excluir(String cpf) {

        try {
            st = conn.prepareStatement("DELETE FROM proprietarios WHERE cpf = ?");
            st.setString(1,cpf);
            st.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
 
    }
    