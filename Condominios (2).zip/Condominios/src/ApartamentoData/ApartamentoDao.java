
package ApartamentoData;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ApartamentoDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public ApartamentoDao() {
    }
    
    public boolean conectar(){
        try {
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            //conn = DriverManager.getConnection("jdbc:sqlserver://localhost;database=banco;integratedSecurity=true;");  
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/condominio", "root","");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
           return false;           
        } 
    }
    
     public int salvar(Apartamento apartamento){
        int status;
        try {
            st = conn.prepareStatement("INSERT INTO apartamento VALUES(?,?,?,?)");
          
            st.setString(1, apartamento.getApartamento());
            st.setString(2, apartamento.getBloco());
            st.setString(3, apartamento.getVaga());
            st.setString(4, apartamento.getNome());
            
          // apartamento, bloco, vaga, nome
            status = st.executeUpdate();
            return status; //retorna 1
        } catch (SQLException ex) {
            return ex.getErrorCode(); 
            //1062 tentativa de inserir uma matrícula já cadastrada.
        }
    }

    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    

       public Apartamento Consultar (String vaga){
    //apartamento, bloco, vaga, nome
    
         try {
            Apartamento apartamento = new Apartamento();
            st = conn.prepareStatement("SELECT * FROM apartamento WHERE vaga = ?");
            st.setString(3,vaga);
            rs = st.executeQuery();
            // verifica se a consulta encontrou o carro com a placa informada
            if(rs.next()){ // se encontrou o apartamento

               apartamento.setVaga(rs.getString("vaga"));
                apartamento.setApartamento(rs.getString("apartamento"));
                apartamento.setBloco(rs.getString("bloco"));
                apartamento.setNome(rs.getString("nome"));
      //apartamento, bloco, vaga, nome
                return apartamento;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null; 
            
        }
         
    }

    public boolean excluir(String vaga) {

        try {
            st = conn.prepareStatement("DELETE FROM apartamento WHERE vaga = ?");
            st.setString(1, vaga);
            st.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

   
}
    

        

 
    
    
    
    

