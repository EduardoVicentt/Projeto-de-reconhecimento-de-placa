
package ApartamentoData;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import ApartamentoData.Apartamento;

/**
 *
 * @author Samuelson
 */
public class ApartamentosDAO {

    public void create(Apartamento p) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO apartamento (vaga,apartamento,bloco,nome)VALUES(?,?,?,?)");
            stmt.setString(1, p.getVaga());
            stmt.setString(2, p.getApartamento());
            stmt.setString(3, p.getBloco());
            stmt.setString(4, p.getNome());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Apartamento> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Apartamento> Apartamentos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM apartamento");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Apartamento ap = new Apartamento();
                
                ap.setIdAp(rs.getInt("IdAp"));
                ap.setVaga(rs.getString("vaga"));
                ap.setApartamento(rs.getString("apartamento"));
                ap.setBloco(rs.getString("bloco"));
                ap.setNome(rs.getString("nome"));
                Apartamentos.add(ap);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ApartamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return Apartamentos;

    }
    
    public Apartamento read_by_vacancy(String vaga) {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Apartamento ap = new Apartamento();

        try {
            String query = "SELECT * FROM apartamento WHERE vaga = ?";
            stmt = con.prepareStatement(query);
            stmt.setString(1, vaga);
            rs = stmt.executeQuery();

            if (rs.next()) {
                ap.setIdAp(rs.getInt("IdAp"));
                ap.setVaga(rs.getString("vaga"));
                ap.setApartamento(rs.getString("apartamento"));
                ap.setBloco(rs.getString("bloco"));
                ap.setNome(rs.getString("nome"));
                
                return ap;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ApartamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return null;
    }
    
    public List<Apartamento> readForDesc(String vag) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Apartamento> Apartamentos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM apartamento WHERE vaga LIKE ?");
            stmt.setString(1, "%"+vag+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Apartamento ap = new Apartamento();
                
                ap.setIdAp(rs.getInt("IdAp"));
                ap.setVaga(rs.getString("vaga"));
                ap.setApartamento(rs.getString("apartamento"));
                ap.setBloco(rs.getString("bloco"));
                ap.setNome(rs.getString("nome"));
                Apartamentos.add(ap);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ApartamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return Apartamentos;

    }

    public void update(Apartamento p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE apartamento SET vaga = ? ,nome = ?,apartamento = ?, bloco = ? WHERE IdAp = ?");
            stmt.setString(1, p.getVaga());
            stmt.setString(2, p.getNome());
            stmt.setString(3, p.getApartamento());
            stmt.setString(4, p.getBloco());
            stmt.setInt(5, p.getIdAp());
           
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public void delete(Apartamento p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM apartamento WHERE IdAp = ?");
             stmt.setInt(1, p.getIdAp());
       
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
}


