package data;

public class Carro {
    //Atributos da classe
    
    private int IdCarro;
    private String nome;
    private String marca;
    private String cor;
    private String placa;
    private String renavan;
    private String modelo;
    

    

    public int getIdCarro() {
        return IdCarro;
    }

    public void setIdCarro(int IdCarro) {
        this.IdCarro = IdCarro;
    }
    public String getnome() {
        return nome;
    }
    public void setnome(String nome) {
        this.nome = nome;
    }

    public String getmarca() {
        return marca;
    }

    public void setmarca(String marca) {
        this.marca = marca;
    }

    public String getcor() {
        return cor;
    }

    public void setcor(String cor) {
        this.cor = cor;
    }

    public String getplaca() {
        return placa;
    }

    public void setplaca(String placa) {
        this.placa = placa;
    }

    public String getrenavan() {
        return renavan;
    }

    public void setrenavan(String renavan) {
        this.renavan = renavan;
    }

    public String getmodelo() {
        return modelo;
    }

    public void setmodelo(String modelo) {
        this.modelo = modelo;
    }
    //Construtor da classe
    public Carro() {
    }

  
}
