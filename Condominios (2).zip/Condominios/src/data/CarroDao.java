
package data;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CarroDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public CarroDao() {
    }
    
    public boolean conectar(){
        try {
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            //conn = DriverManager.getConnection("jdbc:sqlserver://localhost;database=banco;integratedSecurity=true;");  
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/condominio", "root","");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
           return false;           
        } 
    }
    
     public int salvar(Carro carro){
        int status;
        try {
            st = conn.prepareStatement("INSERT INTO carro VALUES(?,?,?,?)");
            st.setString(1, carro.getplaca());
            st.setString(2, carro.getnome());
            st.setString(3, carro.getmarca());
            st.setString(4, carro.getcor());
            st.setString(5, carro.getrenavan());
            st.setString(6, carro.getmarca());
           
            status = st.executeUpdate();
            return status; //retorna 1
        } catch (SQLException ex) {
            return ex.getErrorCode(); 
            //1062 tentativa de inserir uma matrícula já cadastrada.
        }
    }

    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    


    
    
    public Carro consultar (String placa){
        try {
            Carro carro = new Carro();
            st = conn.prepareStatement("SELECT * FROM carro WHERE placa = ?");
            st.setString(1,placa);
            rs = st.executeQuery();
            // verifica se a consulta encontrou o carro com a placa informada
            if(rs.next()){ // se encontrou o carro
                carro.setplaca(rs.getString("placa"));
                carro.setnome(rs.getString("nome"));
                carro.setmarca(rs.getString("marca"));
                carro.setcor(rs.getString("cor"));
                carro.setrenavan(rs.getString("renavan"));
                carro.setmodelo(rs.getString("modelo"));
                //nome, marca, cor, placa, renavan, modelo
                return carro;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null;
        }
    }
 public boolean excluir (String placa){
     
        try {
            st = conn.prepareStatement ("DELETE FROM carro WHERE placa = ?") ;
            st.setString(1,placa);
            st.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
  
     }
}
    
    
    

