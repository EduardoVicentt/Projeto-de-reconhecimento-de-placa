/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import data.Carro;


public class CarrosDAO {

    public void create(Carro p) {

        Connection con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO carro (placa,nome,marca,cor,renavan,modelo)VALUES(?,?,?,?,?,?)");
            
            stmt.setString(1, p.getplaca());
            stmt.setString(2, p.getnome());
            stmt.setString(3, p.getmarca());
            stmt.setString(4, p.getcor());
            stmt.setString(5, p.getrenavan());
            stmt.setString(6, p.getmodelo());
            
            
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Carro> read() {

        Connection con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Carro> carros = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM carro");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Carro carro = new Carro();
                
                carro.setIdCarro(rs.getInt("IdCarro"));
                carro.setplaca(rs.getString("placa"));
                carro.setnome(rs.getString("nome"));
                carro.setmarca(rs.getString("marca"));
                carro.setcor(rs.getString("cor"));
                carro.setrenavan(rs.getString("renavan"));
                carro.setmodelo(rs.getString("modelo"));
                carros.add(carro);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CarrosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return carros;

    }

    public List<Carro> readForDesc(String car) {

        Connection con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Carro> carros = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM carro WHERE placa LIKE ?");
            stmt.setString(1, "%" + car + "%");

            rs = stmt.executeQuery();

            while (rs.next()) {

                Carro carro = new Carro();
                carro.setIdCarro(rs.getInt("IdCarro"));
                carro.setnome(rs.getString("nome"));
                carro.setmarca(rs.getString("marca"));
                carro.setcor(rs.getString("cor"));
                carro.setplaca(rs.getString("placa"));
                carro.setrenavan(rs.getString("renavan"));
                carro.setmodelo(rs.getString("modelo"));
                carros.add(carro);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CarrosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return carros;

    }

    public Carro read_by_plate(String placa) {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Carro veiculo = new Carro();

        try {
            String query = "SELECT * FROM carro WHERE placa = ?";
            stmt = con.prepareStatement(query);
            stmt.setString(1, placa);
            rs = stmt.executeQuery();

            if (rs.next()) {
                veiculo.setIdCarro(rs.getInt("IdCarro"));
                veiculo.setplaca(rs.getString("placa"));
                veiculo.setnome(rs.getString("nome"));
                veiculo.setmarca(rs.getString("marca"));
                veiculo.setcor(rs.getString("cor"));
                veiculo.setrenavan(rs.getString("renavan"));
                veiculo.setmodelo(rs.getString("modelo"));
                
                return veiculo;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(CarrosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return null;
    }    
    
    public void update(Carro p) {

        Connection con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE carro SET  placa = ? , nome = ? ,marca = ?,cor = ?,renavan = ?,modelo = ? WHERE IdCarro = ?");
            stmt.setString(1, p.getplaca());
            stmt.setString(2, p.getnome());
            stmt.setString(3, p.getmarca());
            stmt.setString(4, p.getcor());
            stmt.setString(5, p.getrenavan());
            stmt.setString(6, p.getmodelo());
            stmt.setInt(7, p.getIdCarro());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public void delete(Carro p) {

        Connection con = ConnectionFactory.getConnection();

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM carro WHERE IdCarro = ?");
            stmt.setInt(1, p.getIdCarro());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

}
